# TouringGo — V1

Project Android Studio (Kotlin + Jetpack Compose) yang dibuat sebagai prototipe awal berdasarkan tampilan video referensi.

## Isi V1
- Layout portrait seperti aplikasi navigasi touring.
- Peta prototipe dengan garis rute.
- Panel informasi jarak, kecepatan, dan estimasi waktu.
- Tombol kontrol mengambang.
- Panel preview kamera (placeholder).
- Tombol mulai/berhenti.
- Tombol suara.

## Catatan
V1 ini sengaja belum memakai Google Maps dan kamera asli supaya project awal lebih sederhana.

Tahap berikutnya dapat menambahkan:
1. Google Maps / MapLibre dengan peta asli.
2. GPS posisi pengguna secara real-time.
3. Kamera asli menggunakan CameraX.
4. Routing dan navigasi.
5. Waypoint/anggota konvoi.
6. Rekam perjalanan dan penyimpanan rute.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `TouringGo_V1` di Android Studio.
3. Tunggu Gradle selesai melakukan sync.
4. Jalankan ke HP Android atau emulator.
5. Build > Build APK(s) untuk membuat APK.

Minimum Android: API 26 (Android 8.0).


## Build cloud
Folder `.github/workflows/build-apk.yml` sudah disiapkan untuk GitHub Actions. Agar workflow bisa berjalan, project perlu memiliki Gradle Wrapper (`gradlew`, `gradlew.bat`, dan `gradle/wrapper/gradle-wrapper.jar`).
