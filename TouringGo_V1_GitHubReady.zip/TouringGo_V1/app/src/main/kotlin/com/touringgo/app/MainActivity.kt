package com.touringgo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TouringGoApp() }
    }
}

@Composable
fun TouringGoApp() {
    var cameraOpen by remember { mutableStateOf(true) }
    var started by remember { mutableStateOf(false) }
    var soundOn by remember { mutableStateOf(true) }

    MaterialTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F5F0))
        ) {
            FakeMap()

            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundButton("‹")
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White,
                    shadowElevation = 3.dp
                ) {
                    Text(
                        "TG",
                        modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }
                Button(
                    onClick = { started = !started },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF5B27D8)
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (started) "Berhenti" else "Keluar Konvoi")
                }
            }

            // Camera overlay
            if (cameraOpen) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 76.dp, start = 14.dp, end = 14.dp)
                        .height(225.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .border(3.dp, Color(0xFF1BB6A8), RoundedCornerShape(18.dp))
                        .background(Color(0xFF263238))
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("PREVIEW KAMERA", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            "Kamera perjalanan akan tampil di sini",
                            color = Color.White.copy(alpha = .75f),
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        "×",
                        color = Color.White,
                        fontSize = 24.sp,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                            .clickable { cameraOpen = false }
                    )
                    Text(
                        "⛶",
                        color = Color.White,
                        fontSize = 20.sp,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                    )
                }
            }

            // Floating controls
            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 14.dp, top = 120.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SmallControl("≋")
                SmallControl("⚠")
                SmallControl("3")
                SmallControl("◎")
            }

            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 14.dp, top = 150.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SmallControl("⌁")
                SmallControl("♫", active = soundOn) {
                    soundOn = !soundOn
                }
                SmallControl("⌾")
            }

            // Route card
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(14.dp),
                shape = RoundedCornerShape(22.dp),
                color = Color(0xFFFFF5F5),
                shadowElevation = 7.dp
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEFE9FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("↑", color = Color(0xFF5B27D8), fontSize = 22.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("2,4 km", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Lanjutkan", fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("27 km/j", fontWeight = FontWeight.Bold, color = Color(0xFF4C2AA8))
                            Text("Kecepatan", fontSize = 10.sp)
                        }
                        Spacer(Modifier.width(20.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("119,1 km", fontWeight = FontWeight.Bold, color = Color(0xFF4C2AA8))
                            Text("2j 10m", fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FakeMap() {
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF3F0E9))
    ) {
        // roads
        val road = Color(0xFFD7D0C4)
        repeat(7) { i ->
            val y = size.height * (0.12f + i * 0.12f)
            drawLine(
                road,
                Offset(0f, y),
                Offset(size.width, y + 55f),
                strokeWidth = 2f
            )
        }

        // route shadow and route
        val path = Path().apply {
            moveTo(size.width * .48f, size.height)
            cubicTo(
                size.width * .46f, size.height * .75f,
                size.width * .58f, size.height * .55f,
                size.width * .45f, size.height * .30f
            )
            cubicTo(
                size.width * .40f, size.height * .22f,
                size.width * .38f, size.height * .15f,
                size.width * .32f, size.height * .08f
            )
        }
        drawPath(path, Color(0xFFE9A12B), style = Stroke(9f, cap = StrokeCap.Round))
        drawPath(path, Color(0xFF2C57D8), style = Stroke(5f, cap = StrokeCap.Round))

        // current position
        drawCircle(Color.Black, 14f, Offset(size.width * .48f, size.height * .70f))
        drawCircle(Color(0xFFFFB400), 9f, Offset(size.width * .48f, size.height * .70f))
    }
}

@Composable
fun RoundButton(text: String) {
    Surface(
        shape = CircleShape,
        color = Color.White,
        shadowElevation = 3.dp
    ) {
        Text(text, modifier = Modifier.padding(12.dp), fontSize = 22.sp)
    }
}

@Composable
fun SmallControl(text: String, active: Boolean = false, onClick: (() -> Unit)? = null) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) Color(0xFF1689B9) else Color.White)
            .clickable(enabled = onClick != null) { onClick?.invoke() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 20.sp,
            color = if (active) Color.White else Color(0xFF4B4B4B),
            fontWeight = FontWeight.Bold
        )
    }
}
